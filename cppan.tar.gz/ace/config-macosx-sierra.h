#ifndef ACE_CONFIG_MACOSX_SIERRA_H
#define ACE_CONFIG_MACOSX_SIERRA_H

#include "ace/config-macosx-elcapitan.h"

#endif // ACE_CONFIG_MACOSX_SIERRA_H
